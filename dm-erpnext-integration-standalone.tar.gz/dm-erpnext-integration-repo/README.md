# Digital Marketplace ERPNext Integration

A Frappe application that integrates the UK Government's Digital Marketplace with ERPNext, enabling automated synchronization of procurement opportunities (tenders/briefs) into your ERP system.

## 🚀 Quick Start

```bash
# Install the app
bench get-app https://github.com/YOUR_USERNAME/dm-erpnext-integration.git
bench --site your-site-name install-app dm_erpnext_integration
bench --site your-site-name migrate
```

See **[QUICKSTART.md](QUICKSTART.md)** for detailed setup instructions.

## 📚 Documentation

- **[INDEX.md](INDEX.md)** - Documentation hub with navigation
- **[QUICKSTART.md](QUICKSTART.md)** - 5-minute setup guide
- **[INSTALL.md](INSTALL.md)** - Detailed installation instructions
- **[USER_GUIDE.md](USER_GUIDE.md)** - Daily usage guide with UI mockups
- **[ARCHITECTURE.md](ARCHITECTURE.md)** - System design and architecture
- **[SUMMARY.md](SUMMARY.md)** - Technical overview

## ✨ Features

- 🔄 **Automated Sync**: Hourly sync of briefs, daily sync of frameworks/suppliers
- 📊 **Complete Data Model**: 6 DocTypes covering all Digital Marketplace entities
- 🔐 **Secure Integration**: Token-based authentication
- 👥 **Role-Based Access**: Purchase User and System Manager roles
- 📤 **Export Capabilities**: Excel/CSV export for reporting
- 🔗 **ERPNext Integration**: Link to Projects and Quotations
- 📱 **Mobile Responsive**: Works on all devices

## 📦 What's Included

### DocTypes (6)
- **DM API Settings** - Configuration singleton
- **DM Framework** - G-Cloud, Digital Outcomes & Specialists
- **DM Lot** - Service categories (SaaS, PaaS, IaaS, etc.)
- **DM Brief** - Tenders with full details
- **DM Supplier** - Supplier information
- **DM Service** - Published services

### API Integration
- Robust API client with authentication
- Scheduled sync jobs (hourly/daily)
- Error handling and logging
- Pagination support

## 🎯 Use Cases

1. **Automated Tender Tracking** - Monitor government procurement opportunities
2. **Procurement Planning** - Manage opportunities in your ERP
3. **Bid Management** - Link briefs to projects and quotations
4. **Market Intelligence** - Analyze tender trends and budgets
5. **Supplier Discovery** - Browse Digital Marketplace suppliers

## 📊 Requirements

- Frappe Framework (v13+)
- ERPNext (optional but recommended)
- Python 3.9+
- Digital Marketplace API access token

## 🛠️ Installation

See **[INSTALL.md](INSTALL.md)** for complete installation instructions.

### Quick Install

```bash
# Get the app
cd ~/frappe-bench
bench get-app https://github.com/YOUR_USERNAME/dm-erpnext-integration.git

# Install on your site
bench --site your-site-name install-app dm_erpnext_integration
bench --site your-site-name migrate

# Configure in ERPNext
# Navigate to: DM API Settings
# Add API URL and token
# Enable sync

# Run initial sync
bench --site your-site-name execute dm_erpnext_integration.dm_erpnext_integration.api.sync_frameworks.sync_frameworks_from_api
bench --site your-site-name execute dm_erpnext_integration.dm_erpnext_integration.api.sync_briefs.sync_briefs_from_api
```

## 🧪 Testing

```bash
bench --site your-site-name run-tests --app dm_erpnext_integration
```

## 📖 Documentation Structure

```
dm-erpnext-integration/
├── README.md              # This file (overview)
├── INDEX.md               # Documentation hub
├── QUICKSTART.md          # 5-minute setup
├── INSTALL.md             # Installation guide
├── USER_GUIDE.md          # Daily usage
├── ARCHITECTURE.md        # System design
├── SUMMARY.md             # Technical overview
└── dm_erpnext_integration/
    ├── api/               # API integration
    ├── doctype/           # Data models
    ├── config/            # UI configuration
    └── tests/             # Unit tests
```

## 🤝 Contributing

Contributions are welcome! Please:

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add/update tests
5. Submit a pull request

## 📝 License

MIT License - See [LICENSE](LICENSE) file for details.

## 🔗 Links

- **Digital Marketplace**: https://www.digitalmarketplace.service.gov.uk
- **Frappe Framework**: https://frappeframework.com
- **ERPNext**: https://erpnext.com

## 💡 About

This application was created to automate the integration of UK Government Digital Marketplace procurement opportunities with ERPNext. It provides a complete solution for tracking tenders, managing bids, and analyzing procurement trends.

Based on the Digital Marketplace API: https://github.com/alphagov/digitalmarketplace-api

## 📧 Support

- **Documentation**: See docs linked above
- **Issues**: Open an issue on GitHub
- **Community**: Frappe Forum

---

**Ready to automate your tender management?** See [QUICKSTART.md](QUICKSTART.md) to get started!
