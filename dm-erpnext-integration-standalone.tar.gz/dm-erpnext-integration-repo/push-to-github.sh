#!/bin/bash
# Script to push the Digital Marketplace ERPNext Integration to a new GitHub repository

# Colors for output
GREEN='\033[0;32m'
BLUE='\033[0;34m'
RED='\033[0;31m'
NC='\033[0m' # No Color

echo -e "${BLUE}Digital Marketplace ERPNext Integration - Repository Setup${NC}"
echo "============================================================"
echo ""

# Check if we're in the right directory
if [ ! -f "README.md" ] || [ ! -d "dm_erpnext_integration" ]; then
    echo -e "${RED}Error: Please run this script from the dm-erpnext-integration-repo directory${NC}"
    exit 1
fi

# Prompt for GitHub repository URL
echo -e "${BLUE}Step 1: Enter your new GitHub repository details${NC}"
echo ""
read -p "Enter your GitHub repository URL (e.g., https://github.com/username/dm-erpnext-integration.git): " REPO_URL

if [ -z "$REPO_URL" ]; then
    echo -e "${RED}Error: Repository URL is required${NC}"
    exit 1
fi

echo ""
echo -e "${GREEN}Repository URL: $REPO_URL${NC}"
echo ""

# Check if remote already exists
if git remote | grep -q "origin"; then
    echo -e "${BLUE}Removing existing 'origin' remote...${NC}"
    git remote remove origin
fi

# Add new remote
echo -e "${BLUE}Step 2: Adding remote...${NC}"
git remote add origin "$REPO_URL"

if [ $? -ne 0 ]; then
    echo -e "${RED}Error: Failed to add remote${NC}"
    exit 1
fi

echo -e "${GREEN}✓ Remote added successfully${NC}"
echo ""

# Verify we have a commit
COMMIT_COUNT=$(git rev-list --count HEAD 2>/dev/null || echo "0")
if [ "$COMMIT_COUNT" -eq "0" ]; then
    echo -e "${BLUE}Creating initial commit...${NC}"
    git add .
    git commit -m "Initial commit: Digital Marketplace ERPNext Integration"
fi

# Show what will be pushed
echo -e "${BLUE}Step 3: Ready to push${NC}"
echo ""
echo "Files to be pushed:"
git ls-files | head -10
echo "... and $(git ls-files | wc -l) files total"
echo ""

# Confirm before pushing
read -p "Push to remote repository? (y/N): " CONFIRM

if [ "$CONFIRM" != "y" ] && [ "$CONFIRM" != "Y" ]; then
    echo -e "${BLUE}Push cancelled. You can push later with: git push -u origin main${NC}"
    exit 0
fi

# Push to remote
echo ""
echo -e "${BLUE}Pushing to remote...${NC}"
git push -u origin main

if [ $? -eq 0 ]; then
    echo ""
    echo -e "${GREEN}✓ Successfully pushed to remote!${NC}"
    echo ""
    echo -e "${BLUE}Next steps:${NC}"
    echo "1. Verify the repository at: $(echo $REPO_URL | sed 's/\.git$//')"
    echo "2. Set repository visibility to Private (if not already)"
    echo "3. Update README.md with your repository URL"
    echo "4. Test installation: bench get-app $REPO_URL"
    echo ""
else
    echo ""
    echo -e "${RED}Error: Failed to push to remote${NC}"
    echo "You may need to:"
    echo "1. Create the repository on GitHub first"
    echo "2. Check your credentials (git credential fill)"
    echo "3. Verify the repository URL"
    echo ""
    echo "Manual push command: git push -u origin main"
    exit 1
fi
